package com.example.lista3;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.lista3.databinding.OcenyItemBinding;

import java.util.ArrayList;
import java.util.List;

public class OcenyAdapter extends RecyclerView.Adapter<OcenyViewHolder> {
    private List<SubjectWithGrades> items;

    public OcenyAdapter(List<SubjectWithGrades> items) {
        this.items = items;
    }

    @NonNull
    @Override
    public OcenyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new OcenyViewHolder(OcenyItemBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false
        ));
    }

    @Override
    public void onBindViewHolder(@NonNull OcenyViewHolder holder, int position) {
        SubjectWithGrades currentItem = items.get(position);
        holder.bind(currentItem);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }
}
