package com.example.lista3;

public interface OnItemClickListener {
    void onItemClick(int position);
}
