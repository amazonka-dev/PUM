package com.example.lista3;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class DataGenerator {
    public static List<ExcerciseList> generateData() {
        Random random = new Random();
        List<Integer> listNumberPerSubject = new ArrayList<>();
        for (int i = 0; i < getSubjects().size(); i++) {
            listNumberPerSubject.add(0);
        }

        List<ExcerciseList> excerciseLists = new ArrayList<>();
        for (int i = 0; i < 20; i++) {
            int subjectIndex = random.nextInt(getSubjects().size());
            listNumberPerSubject.set(subjectIndex, listNumberPerSubject.get(subjectIndex) + 1);
            ExcerciseList excerciseList = new ExcerciseList(getSubjects().get(subjectIndex), 3 + random.nextInt(5) * 0.5, listNumberPerSubject.get(subjectIndex));
            int exercises = 1 + random.nextInt(10);
            for (int j = 0; j < exercises; j++) {
                Exercise exercise = new Exercise(getTaskContent(), random.nextInt(11), j + 1);
                excerciseList.getExcercises().add(exercise);
            }
            excerciseLists.add(excerciseList);
        }
        return excerciseLists;
    }

    private static List<String> getSubjects() {
        List<String> subjects = new ArrayList<>();
        subjects.add("Matematyka");
        subjects.add("PUM");
        subjects.add("Fizyka");
        subjects.add("Elektronika");
        subjects.add("Algorytmy");
        return subjects;
    }

    private static String getTaskContent() {
        String loremIpsum = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.";
        Random random = new Random();
        return loremIpsum.substring(0, 20 + random.nextInt(60));
    }
}
