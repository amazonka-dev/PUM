package com.example.lista3;

import androidx.recyclerview.widget.RecyclerView;

import com.example.lista3.databinding.ListyZadanItemBinding;

public class ListyZadanViewHolder extends RecyclerView.ViewHolder {
    private ListyZadanItemBinding binding;

    public ListyZadanViewHolder(ListyZadanItemBinding binding, OnItemClickListener onItemClickListener) {
        super(binding.getRoot());
        this.binding = binding;
        binding.getRoot().setOnClickListener(v ->
                onItemClickListener.onItemClick(getAdapterPosition()));
    }

    public void bind(ExcerciseList item) {
        binding.liczbazadan.setText(String.format("Liczba zadań: %d", item.getExcercises().size()));
        binding.numerlisty.setText((String.format("Lista: %d", item.getListNumber())));
        binding.przedmiot.setText(item.getSubject());
        binding.ocena.setText((String.format("Ocena: %.1f", item.getGrade())));
    }


}
