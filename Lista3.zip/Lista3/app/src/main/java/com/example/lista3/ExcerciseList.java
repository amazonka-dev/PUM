package com.example.lista3;

import java.util.ArrayList;
import java.util.List;

public class ExcerciseList {
    private List<Exercise> excercises;
    private String subject;
    private Double grade;
    private Integer listNumber;

    public ExcerciseList(String subject, Double grade, Integer listNumber) {
        this.subject = subject;
        this.grade = grade;
        this.listNumber = listNumber;
        this.excercises = new ArrayList<>();

    }

    public List<Exercise> getExcercises() {
        return excercises;
    }

    public void setExcercises(List<Exercise> excercises) {
        this.excercises = excercises;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public Double getGrade() {
        return grade;
    }

    public void setGrade(Double grade) {
        this.grade = grade;
    }

    public Integer getListNumber() {
        return listNumber;
    }

    public void setListNumber(Integer listNumber) {
        this.listNumber = listNumber;
    }
}
