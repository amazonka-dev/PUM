package com.example.lista3;

import java.util.ArrayList;
import java.util.List;

public class Database {
    public static List<ExcerciseList> excerciseLists = new ArrayList<>();

    public static List<SubjectWithGrades> getSubjectsWithGrades() {
        List<SubjectWithGrades> result = new ArrayList<>();
        for (ExcerciseList excerciseList : excerciseLists) {
            SubjectWithGrades matchingSubjectWithGrades = null;
            for (SubjectWithGrades sg : result) {
                if (sg.getSubject().equals(excerciseList.getSubject())) {
                    matchingSubjectWithGrades = sg;
                    break;
                }
            }

            if (matchingSubjectWithGrades == null) {
                matchingSubjectWithGrades = new SubjectWithGrades(excerciseList.getSubject(), excerciseList.getGrade(), 1);
                result.add(matchingSubjectWithGrades);
            } else {
                matchingSubjectWithGrades.setAverage(matchingSubjectWithGrades.getAverage() + excerciseList.getGrade());
                matchingSubjectWithGrades.setTotalLists(matchingSubjectWithGrades.getTotalLists() + 1);
            }
        }

        for (SubjectWithGrades sg : result) {
            sg.setAverage(sg.getAverage() / sg.getTotalLists());
        }
        return result;
    }

    public static ExcerciseList findExerciseList(String subject, int listNumber) {

        for (ExcerciseList excerciseList : excerciseLists) {
            if (excerciseList.getSubject().equals(subject) && excerciseList.getListNumber().equals(listNumber)) {
                return excerciseList;
            }
        }
        return null;
    }
}
