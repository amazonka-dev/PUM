package com.example.lista3;

public class Exercise {
    private String content;
    private Integer points;
    private Integer excerciseNumber;

    public Exercise(String content, Integer points, Integer excerciseNumber) {
        this.content = content;
        this.points = points;
        this.excerciseNumber = excerciseNumber;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Integer getPoints() {
        return points;
    }

    public void setPoints(Integer points) {
        this.points = points;
    }

    public Integer getExcerciseNumber() {
        return excerciseNumber;
    }

    public void setExcerciseNumber(Integer excerciseNumber) {
        this.excerciseNumber = excerciseNumber;
    }
}
