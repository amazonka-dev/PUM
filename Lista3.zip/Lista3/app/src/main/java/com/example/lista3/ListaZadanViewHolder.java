package com.example.lista3;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.lista3.databinding.ListaZadanItemBinding;

public class ListaZadanViewHolder extends RecyclerView.ViewHolder {
    private ListaZadanItemBinding binding;

    public ListaZadanViewHolder(@NonNull ListaZadanItemBinding binding) {
        super(binding.getRoot());
        this.binding = binding;
    }
    public void bind(Exercise item){
        binding.numerzadania.setText(String.format("Zadanie %d", item.getExcerciseNumber()));
        binding.punkty.setText(String.format("pkt.: %d", item.getPoints()));
        binding.tresczadania.setText(item.getContent());
    }
}
