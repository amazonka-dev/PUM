package com.example.lista3;

public class SubjectWithGrades {
    private String subject;
    private Double average;
    private Integer totalLists;

    public SubjectWithGrades(String subject, Double average, Integer totalLists) {
        this.subject = subject;
        this.average = average;
        this.totalLists = totalLists;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public Double getAverage() {
        return average;
    }

    public void setAverage(Double average) {
        this.average = average;
    }

    public Integer getTotalLists() {
        return totalLists;
    }

    public void setTotalLists(Integer totalLists) {
        this.totalLists = totalLists;
    }
}
