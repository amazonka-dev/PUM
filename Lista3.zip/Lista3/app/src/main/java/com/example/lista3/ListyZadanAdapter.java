package com.example.lista3;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.lista3.databinding.ListyZadanItemBinding;

import java.util.ArrayList;
import java.util.List;

public class ListyZadanAdapter extends RecyclerView.Adapter<ListyZadanViewHolder> {
    private List<ExcerciseList> items;
    private final OnItemClickListener onItemClickListener;
    public ListyZadanAdapter(List<ExcerciseList> items, OnItemClickListener onItemClickListener)
    {
        this.items = items;
        this.onItemClickListener = onItemClickListener;
    }

    @NonNull
    @Override
    public ListyZadanViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ListyZadanViewHolder(ListyZadanItemBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false
        ), onItemClickListener);
    }

    @Override
    public void onBindViewHolder(@NonNull ListyZadanViewHolder holder, int position) {
        ExcerciseList currentItem = items.get(position);
        holder.bind(currentItem);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }
}
