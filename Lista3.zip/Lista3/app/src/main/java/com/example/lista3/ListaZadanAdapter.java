package com.example.lista3;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.lista3.databinding.ListaZadanItemBinding;

import java.util.ArrayList;
import java.util.List;

public class ListaZadanAdapter extends RecyclerView.Adapter<ListaZadanViewHolder> {
    private List<Exercise> items;

    public ListaZadanAdapter(List<Exercise> items){
        this.items = items;
    }

    @NonNull
    @Override
    public ListaZadanViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ListaZadanViewHolder(ListaZadanItemBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false
        ));
    }

    @Override
    public void onBindViewHolder(@NonNull ListaZadanViewHolder holder, int position) {
        Exercise currentItem = items.get(position);
        holder.bind(currentItem);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }
}
