package com.example.lista3;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.lista3.databinding.OcenyItemBinding;

public class OcenyViewHolder extends RecyclerView.ViewHolder {
    private OcenyItemBinding binding;

    public OcenyViewHolder(@NonNull OcenyItemBinding binding) {
        super(binding.getRoot());
        this.binding = binding;
    }
    public void  bind(SubjectWithGrades item) {
        binding.przedmiot.setText(item.getSubject());
        binding.srednia.setText(String.format("Średnia: %.1f", item.getAverage()));
        binding.liczbalist.setText(String.format("Liczba list: %d", item.getTotalLists()));
    }
}
