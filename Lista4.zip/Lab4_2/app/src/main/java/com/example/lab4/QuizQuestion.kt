package com.example.lab4

import kotlin.random.Random

class QuizQuestion(val question: String, val answers: List<String>, val correctAnswer: Int)

fun generateQuestions(): List<QuizQuestion> {
    val questionList = mutableListOf<QuizQuestion>()
    for (i in 1..10) {
        val x = Random.nextInt(1, 10)
        val y = Random.nextInt(1, 10)
        val result = x * y
        val question = "$x * $y = ?"
        val answers = listOf(
            "$result",
            "${Random.nextInt(100, 200)}",
            "${Random.nextInt(100, 200)}",
            "${Random.nextInt(100, 200)}"
        )
        val quizQuestion = QuizQuestion(question, answers, 0)
        questionList.add(quizQuestion)
    }
    return questionList
}