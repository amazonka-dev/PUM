package com.example.lab4

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.lab4.ui.theme.Lab4Theme
import kotlinx.coroutines.selects.select

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val quizQuestions = generateQuestions()
        setContent {
            Lab4Theme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Quiz(
                        quizQuestions,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun Quiz(quizQuestions: List<QuizQuestion>, modifier: Modifier = Modifier) {
    var currentQuestionIndex by remember { mutableIntStateOf(0) }
    var points by remember {
        mutableIntStateOf(0)
    }
    if (currentQuestionIndex >= quizQuestions.size) {
        ShowResults(points, modifier)
    } else {
        val currentQuestion = quizQuestions[currentQuestionIndex]
        var selectedAnswer by remember {
            mutableIntStateOf(-1)
        }
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = modifier.padding(horizontal = 30.dp, vertical = 10.dp)
        )
        {
            Text("Pytanie ${currentQuestionIndex + 1} / ${quizQuestions.size}", fontSize = 20.sp)
            LinearProgressIndicator(progress = {
                (currentQuestionIndex + 1).toFloat() / quizQuestions.size
            })
            Text(currentQuestion.question, fontSize = 20.sp)
            for ((index, answer) in currentQuestion.answers.withIndex()) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    RadioButton(selected = selectedAnswer == index, onClick = {
                        selectedAnswer = index
                    })
                    Text(answer, fontSize = 20.sp, modifier = Modifier.clickable {
                        selectedAnswer = index
                    })
                }
            }
            Button(onClick = {
                if (selectedAnswer > -1) {
                    if (selectedAnswer == currentQuestion.correctAnswer) {
                        points += 10
                    }
                    currentQuestionIndex += 1
                    selectedAnswer = -1
                }
            }) {
                Text("Następne", fontSize = 20.sp)
            }
        }
    }
}

@Composable
fun ShowResults(points: Int, modifier: Modifier = Modifier) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier.padding(horizontal = 30.dp, vertical = 10.dp)
    ) {
        Text(
            "Gratulacje! Zdobyłeś $points punktów.",
            fontSize = 20.sp,
        )
    }
}

@Preview
@Composable
fun ShowResultsPreview() {
    Lab4Theme {
        ShowResults(points = 10)
    }
}