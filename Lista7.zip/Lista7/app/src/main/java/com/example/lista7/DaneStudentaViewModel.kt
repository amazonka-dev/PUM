package com.example.lista7

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider


class DaneStudentaViewModel(nrIndeksu: Int) : ViewModel() {
    private var _student = MutableLiveData(Database.znajdzStudenta(nrIndeksu))
    val student: LiveData<Student>
        get() = _student
}

class DaneStudentaViewModelFactory(val nrIndeksu: Int) :
    ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return DaneStudentaViewModel(nrIndeksu) as T
    }
}