package com.example.lista7

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class ListaStudentowViewModel: ViewModel (){
    private var _studenci = MutableLiveData(Database.studenci)
    val studenci: LiveData<List<Student>>
        get() = _studenci
}