package com.example.lista7

class Student (val nrIndeksu: Int, val imie: String, val nazwisko: String, val srednia: Double, val rok: Int){
}