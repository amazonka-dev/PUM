package com.example.lista7

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.lista7.ui.theme.Lista7Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val navController = rememberNavController()
            Lista7Theme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        Navigation(navController)
                    }
                }
            }
        }
    }
}

sealed class Screens(val route: String) {
    data object ListaStudentowScreen : Screens("lista_studentow_screen")
    data object DaneStudentaScreen : Screens("dane_studenta_screen")

}

@Composable
fun Navigation(navController: NavHostController) {
    NavHost(navController = navController, startDestination = Screens.ListaStudentowScreen.route) {
        composable(route = Screens.ListaStudentowScreen.route) {
            ListaStudentowScreen(studentClicked = { nrIndeksu ->
                navController.navigate(Screens.DaneStudentaScreen.route + "/$nrIndeksu")
            })
        }

        composable(route = Screens.DaneStudentaScreen.route + "/{nrIndeksu}",
            arguments = listOf(
                navArgument("nrIndeksu") {
                    type = NavType.IntType
                }
            )) {
            val nrIndeksu = it.arguments?.getInt("nrIndeksu")!!
            DaneStudentaScreen(nrIndeksu)
        }

    }
}

@Composable
fun ListaStudentowScreen(studentClicked: (Int) -> Unit) {
    val viewModel: ListaStudentowViewModel = viewModel()
    val studenciState = viewModel.studenci.observeAsState()
    val studenci = studenciState.value!!

    Column {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            items(studenci.size) {
                val student by remember {
                    mutableStateOf(studenci[it])
                }
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp)
                        .clickable(onClick = {
                            studentClicked(student.nrIndeksu)
                        })
                ) {
                    Text("${student.nrIndeksu}", fontSize = 20.sp)
                    Text(student.imie, fontSize = 20.sp)
                    Text(student.nazwisko, fontSize = 20.sp)
                }
            }
        }
    }
}

@Composable
fun DaneStudentaScreen(nrIndeksu: Int) {
    val viewModel: DaneStudentaViewModel = viewModel(
        LocalViewModelStoreOwner.current!!,
        "DaneStudentaViewModel",
        DaneStudentaViewModelFactory(nrIndeksu)
    )
    val studentState = viewModel.student.observeAsState()
    val student = studentState.value!!

    Column {

        Text("Numer indeksu: ${student.nrIndeksu}", fontSize = 20.sp)
        Text("Imię: ${student.imie}", fontSize = 20.sp)
        Text("Nazwisko: ${student.nazwisko}", fontSize = 20.sp)
        Text("Srednia ocen: %.1f".format(student.srednia), fontSize = 20.sp)
        Text("Rok studiów: ${student.rok}", fontSize = 20.sp)
    }
}
