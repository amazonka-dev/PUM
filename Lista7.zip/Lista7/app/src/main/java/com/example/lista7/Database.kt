package com.example.lista7

import kotlin.random.Random

val imiona = listOf(
    "Piotr",
    "Paweł",
    "Aleksandra",
    "Stefan",
    "Anna",
    "Ewa",
    "Maria",
    "Stanisław",
    "Andrzej",
    "Leon",
    "Marek",
    "Mariola"
)

val nazwiska = listOf(
    "Malinowski",
    "Nowak",
    "Koniecpolski",
    "Moniuszko",
    "Piwnik",
    "Bobrowicz",
    "Matysiak",
    "Kuśmider",
    "Nałkowski"
)
class Database {
    companion object {
        val studenci = generujStudentow()
        fun znajdzStudenta(nrIndeksu: Int): Student {
          return studenci.find {it.nrIndeksu == nrIndeksu}!!
        }
    }
}

fun generujStudentow(): List<Student> {
    val studenci = mutableListOf<Student>()
    for (i in 1..10) {
        val student = Student(
            nrIndeksu = (100000..999999).random(),
            imie = imiona.random(),
            nazwisko = nazwiska.random(),
            srednia = 2 + Random.nextInt(7) * 0.5,
            rok = Random.nextInt(1, 6),
        )
        studenci.add(student)
    }
    return studenci
}