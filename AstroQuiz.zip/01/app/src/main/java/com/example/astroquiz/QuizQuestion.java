package com.example.astroquiz;

import java.util.List;

public class QuizQuestion {
    private String question;
    private List<String> answers;
    private int correctAnswer;

    public QuizQuestion(int correctAnswer, List<String> answers, String question) {
        this.correctAnswer = correctAnswer;
        this.answers = answers;
        this.question = question;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public List<String> getAnswers() {
        return answers;
    }

    public void setAnswers(List<String> answers) {
        this.answers = answers;
    }

    public int getCorrectAnswer() {
        return correctAnswer;
    }
}
