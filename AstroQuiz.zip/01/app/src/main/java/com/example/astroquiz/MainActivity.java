package com.example.astroquiz;

import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.astroquiz.databinding.ActivityMainBinding;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;
    private List<QuizQuestion> pytania;
    private Integer biezace_pytanie;
    private Integer suma_punktow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        pytania = wygenerujPytania();
        pokazPytania();
        binding.nastepne.setOnClickListener(view -> {
            if (czyBiezacaOdpowiedzPoprawna()) {
                suma_punktow = suma_punktow + 10;
            }

            biezace_pytanie = biezace_pytanie + 1;
            if (biezace_pytanie < pytania.size()) {
                wyswietlBiezacePytanie();
            }
            else {
                wyswietlPunktacje();
            }
        });
    }

    private List<QuizQuestion> wygenerujPytania() {
        List<QuizQuestion> quizQuestionList = new ArrayList<>();
        quizQuestionList.add(new QuizQuestion(1, List.of("Proxima Centuri", "Słońce", "Syriusz", "Betelgeza"), "Jak nazywa się najbliższa Ziemi gwiazda??"));
        quizQuestionList.add(new QuizQuestion(0, List.of("Odległość, którą światło pokonuje w ciągu jednego roku", "Czas, jaki zajmuje Ziemi pełen obieg wokół Słońca", "Czas trwania jednego dnia na Marsie", "Okres między dwiema pełniami Księżyca"), "Co to jest rok świetlny?"));
        quizQuestionList.add(new QuizQuestion(2, List.of("Andromeda", "Betelgeza", "Mars", "Proxima Centuri"), "Który z obiektów znajduje się w Układzie Słonecznym?"));
        quizQuestionList.add(new QuizQuestion(1, List.of("Ziemia", "Jowisz", "Saturn", "Neptun"), "Jak nazywa się największa planeta w Układzie Słonecznym?"));
        quizQuestionList.add(new QuizQuestion(2, List.of("Albert Einstein", "Johannes Kepler", "Isaac Newton", "Galileo Galilei"), "Kto sformułował prawo powszechnego ciążenia?"));
        quizQuestionList.add(new QuizQuestion(2, List.of("Now", "Nów", "Pełnia", "Półksiężyc"), "Jak nazywa się faza Księżyca, w której Księżyc jest całkowicie oświetlony?"));
        quizQuestionList.add(new QuizQuestion(1, List.of("Mars", "Wenus", "Jowisz", "Uran"), "Która planeta Układu Słonecznego ma najbardziej zbliżoną wielkość do Ziemi?"));
        quizQuestionList.add(new QuizQuestion(2, List.of("Merkury", "Wenus", "Uran", "Mars"), "Które z poniższych ciał niebieskich to gazowy olbrzym?"));
        quizQuestionList.add(new QuizQuestion(1, List.of("Wielka Mgławica w Orionie", "Droga Mleczna", "Kometa Halleya", "Księżyc"), "Który z wymienionych obiektów to galaktyka?"));
        quizQuestionList.add(new QuizQuestion(1, List.of("Zaćmienie Księżyca", "Zaćmienie Słońca", "Koniunkcja planet", "Kwadratura Księżyca"), "Jak nazywa się zjawisko, kiedy Księżyc przechodzi między Ziemią a Słońcem, zasłaniając je?"));
        return quizQuestionList;


    }

    private void wyswietlBiezacePytanie() {
        binding.numerPytania.setText(String.format("Pytanie %d/%d", biezace_pytanie + 1, pytania.size()));
        binding.progressBar.setProgress(biezace_pytanie + 1);
        QuizQuestion question = pytania.get(biezace_pytanie);
        binding.pytanie.setText(question.getQuestion());
        binding.radioButton1.setText(question.getAnswers().get(0));
        binding.radioButton2.setText(question.getAnswers().get(1));
        binding.radioButton3.setText(question.getAnswers().get(2));
        binding.radioButton4.setText(question.getAnswers().get(3));
        binding.grupa.clearCheck();

    }

    private void wyswietlPunktacje() {
        binding.widokPytania.setVisibility(View.GONE);
        binding.podsumowanie.setVisibility((View.VISIBLE));
        binding.punktacja.setText(String.format("Zdobyłeś %d pkt.", suma_punktow));
    }

    private void pokazPytania() {
        binding.widokPytania.setVisibility(View.VISIBLE);
        binding.podsumowanie.setVisibility((View.GONE));
        biezace_pytanie = 0;
        suma_punktow = 0;
        wyswietlBiezacePytanie();
    }

    private boolean czyBiezacaOdpowiedzPoprawna() {
        QuizQuestion pytanie = pytania.get(biezace_pytanie);
        int poprawnaOdpowiedz = pytanie.getCorrectAnswer();
        int checkedId = binding.grupa.getCheckedRadioButtonId();
        if (poprawnaOdpowiedz == 0) {
            return binding.radioButton1.getId() == checkedId;
        }
        if (poprawnaOdpowiedz == 1) {
            return binding.radioButton2.getId() == checkedId;
        }
        if (poprawnaOdpowiedz == 2) {
            return binding.radioButton3.getId() == checkedId;
        }
        if (poprawnaOdpowiedz == 3) {
            return binding.radioButton4.getId() == checkedId;
        }
        return false;

    }
}