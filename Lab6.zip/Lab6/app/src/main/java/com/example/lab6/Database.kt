package com.example.lab6

class Database {
    companion object {
        fun findExerciseList(subject: String, listNumber: Int): ExerciseList {
            return exerciseLists.find { it.subject == subject && it.listNumber == listNumber }!!

        }

        fun getSubjectWithGrades(): List<SubjectWithGrades> {
            val allSubjectsWithGrades = mutableListOf<SubjectWithGrades>()
            for (subject in getSubjects()) {
                val exerciseListsOfSubject = exerciseLists.filter { it.subject == subject }
                if (exerciseListsOfSubject.isEmpty()) {
                    continue
                }
                var total = 0.0
                for (exerciseList in exerciseListsOfSubject) {
                    total += exerciseList.grade
                }
                val subjectWithGrades = SubjectWithGrades(
                    subject,
                    total / exerciseListsOfSubject.size,
                    exerciseListsOfSubject.size
                )
                allSubjectsWithGrades.add(subjectWithGrades)
            }
            return allSubjectsWithGrades
        }

        val exerciseLists = generateData()
    }
}