package com.example.lab6

class Exercise (val content: String, val points: Int, val exerciseNumber: Int)

class ExerciseList (val subject: String, val grade: Double, val listNumber: Int) {
    val excercises = mutableListOf<Exercise>()
}

class Subject (val name: String)

class SubjectWithGrades (val subject: String, val average: Double, val totalLists: Int)