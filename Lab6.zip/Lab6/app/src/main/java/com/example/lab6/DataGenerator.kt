package com.example.lab6

import kotlin.random.Random

fun generateData(): List<ExerciseList> {
    val exerciseLists = mutableListOf<ExerciseList>()
    val subjects = getSubjects()

    val listNumberPerSubject = mutableListOf<Int>()
    for (i in 0..subjects.size) {
        listNumberPerSubject.add(0)
    }
    for (i in 0..20) {
        val subjectIndex = Random.nextInt(subjects.size)
        listNumberPerSubject[subjectIndex]++
        val exerciseList = ExerciseList(
            subjects[subjectIndex],
            3 + Random.nextInt(6) * 0.5,
            listNumberPerSubject[subjectIndex]
        )
        for (j in 0..Random.nextInt(11)) {
            val exercise = Exercise(getTaskContent(), 1 + Random.nextInt(11), j + 1)
            exerciseList.excercises.add(exercise)
        }
        exerciseLists.add(exerciseList)
    }
    return exerciseLists
}

fun getSubjects(): List<String> {
    return listOf("Matematyka", "PUM", "Fizyka", "Elektronika", "Algorytmy")
}

fun getTaskContent(): String {
    val loremIpsum =
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
    return loremIpsum.substring(0, 20 + Random.nextInt(60))
}