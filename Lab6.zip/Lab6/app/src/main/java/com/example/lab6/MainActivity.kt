package com.example.lab6

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.lab6.ui.theme.Lab6Theme


import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavType
import androidx.navigation.navArgument

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val navController = rememberNavController()
            Lab6Theme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        BottomMenu(navController = navController)
                    }
                ) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        Navigation(navController)
                    }
                }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

sealed class Screens(val route: String) {
    data object ListyZadanScreen : Screens("listy_zadan_screen")
    data object ListaZadanScreen : Screens("lista_zadan_screen")
    data object ListaOcenScreen : Screens("lista_ocen_screen")
}

@Composable
fun Navigation(navController: NavHostController) {
    NavHost(navController = navController, startDestination = Screens.ListyZadanScreen.route) {
        composable(route = Screens.ListyZadanScreen.route) {
            ListyZadanScreen(listaZadanClicked = { subject, listNumber ->
                navController.navigate(Screens.ListaZadanScreen.route + "/$subject/$listNumber")
            })
        }

        composable(route = Screens.ListaZadanScreen.route + "/{subject}/{listNumber}",
            arguments = listOf(
                navArgument("subject") {
                    type = NavType.StringType
                }, navArgument("listNumber") {
                    type = NavType.IntType
                }
            )) {
            val subject = it.arguments?.getString("subject")!!
            val listNumber = it.arguments?.getInt("listNumber")!!
            ListaZadanScreen(subject, listNumber)
        }
        composable(route = Screens.ListaOcenScreen.route) {
            ListaOcenScreen()
        }
    }
}

@Composable
fun ListyZadanScreen(listaZadanClicked: (String, Int) -> Unit) {
    Column {
        Text(
            "Moje Listy Zadań",
            fontSize = 20.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        )
        val exerciseLists = Database.exerciseLists
        LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            items(exerciseLists.size) {
                val exerciseList by remember {
                    mutableStateOf(exerciseLists[it])
                }
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp)
                        .clickable(onClick = {
                            listaZadanClicked(exerciseList.subject, exerciseList.listNumber)
                        })
                ) {
                    Column {
                        Text(exerciseList.subject, fontSize = 20.sp)
                        Text("Liczba zadań: ${exerciseList.excercises.size}")

                    }
                    Column {
                        Text("Lista ${exerciseList.listNumber}", fontSize = 20.sp)
                        Text("Ocena: ${exerciseList.grade}")
                    }
                }
            }
        }
    }

}

@Composable
fun ListaZadanScreen(subject: String, listNumber: Int) {
    Column {
        val exerciseList = Database.findExerciseList(subject, listNumber)
        Text(
            "${exerciseList.subject}\nLista ${listNumber}",
            fontSize = 20.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        )
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(16.dp),

            ) {
            items(exerciseList.excercises.size) {
                val exercise by remember {
                    mutableStateOf(exerciseList.excercises[it])
                }
                Column(modifier = Modifier.padding(all = 10.dp)) {
                    Text("Zadanie ${exercise.exerciseNumber}", fontSize = 20.sp)
                    Text(exercise.content)
                    Text("pkt. ${exercise.points}")
                }
            }
        }
    }
}

@Composable
fun ListaOcenScreen() {
    Column {
        Text(
            "Moje Oceny",
            textAlign = TextAlign.Center,
            fontSize = 20.sp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        )
        val subjectsWithGrades = Database.getSubjectWithGrades()
        LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            items(subjectsWithGrades.size) {
                val subjectWithGrades by remember {
                    mutableStateOf(subjectsWithGrades[it])
                }
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp)
                )
                {
                    Column {
                        Text(subjectWithGrades.subject)
                        Text("Liczba list: ${subjectWithGrades.totalLists}")
                    }
                    Column {
                        Text("Średnia: ${"%.1f".format(subjectWithGrades.average)}")
                    }
                }
            }
        }
    }
}


sealed class BottomBar(
    val route: String,
    val title: String,
    val icon: ImageVector
) {
    data object ListyZadan :
        BottomBar(Screens.ListyZadanScreen.route, "Listy zadań", Icons.Default.Home)

    data object ListaOcen :
        BottomBar(Screens.ListaOcenScreen.route, "Lista ocen", Icons.Default.Info)
}

@Composable
fun BottomMenu(navController: NavHostController) {
    val screens = listOf(
        BottomBar.ListyZadan, BottomBar.ListaOcen
    )

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    NavigationBar {
        screens.forEach { screen ->
            NavigationBarItem(
                label = { Text(text = screen.title) },
                icon = { Icon(imageVector = screen.icon, contentDescription = "icon") },
                selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true,
                onClick = { navController.navigate(screen.route) }
            )
        }
    }
}
