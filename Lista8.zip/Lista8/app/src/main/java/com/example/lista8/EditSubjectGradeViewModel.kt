package com.example.lista8

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class EditSubjectGradeViewModel(val subjectGradeId: Int, application: Application) : ViewModel() {

    private val _subjectStateFlow = MutableStateFlow("")
    val subjectStateFlow = _subjectStateFlow.asStateFlow()

    private val _gradeStateFlow = MutableStateFlow("0")
    val gradeStateFlow = _gradeStateFlow.asStateFlow()

    private val repository: SubjectGradeRepository

    init {
        val db = SubjectGradeDatabase.getDatabase(application)
        val dao = db.SubjectGradeDao()
        repository = SubjectGradeRepository(dao)

        fetchSubjectGrade()

    }

    fun fetchSubjectGrade() {
        viewModelScope.launch {
            val subjectGrade = repository.findSubjectGradeById(subjectGradeId)
            _subjectStateFlow.update { subjectGrade.subject }
            _gradeStateFlow.update { "%.1f".format(subjectGrade.grade) }
        }
    }

    fun deleteSubjectGrade() {
        viewModelScope.launch {
            repository.delete(subjectGradeId)
        }
    }

    fun updateSubjectGrade(subject: String, grade: Double) {
        viewModelScope.launch {
            repository.update(SubjectGrade(subjectGradeId, subject, grade))
        }
    }

    fun updateSubject(subject: String) {
        _subjectStateFlow.update { subject }
    }

    fun updateGrade(grade: String) {
        _gradeStateFlow.update { grade }
    }
}

class EditSubjectGradeViewModelFactory(val subjectGradeId: Int, val application: Application) :
    ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return EditSubjectGradeViewModel(subjectGradeId, application) as T
    }
}
