package com.example.lista8

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class SubjectGradeListViewModel(application: Application) : ViewModel() {

    private val repository: SubjectGradeRepository
    private val _subjectGradesStateFlow = MutableStateFlow<List<SubjectGrade>>(emptyList())
    val subjectGradesStateFlow: StateFlow<List<SubjectGrade>>
        get() = _subjectGradesStateFlow

    private val _averageGradeStateFlow = MutableStateFlow(0.0)
    val averageGradeStateFlow = _averageGradeStateFlow.asStateFlow()

    init {
        val db = SubjectGradeDatabase.getDatabase(application)
        val dao = db.SubjectGradeDao()
        repository = SubjectGradeRepository(dao)

        fetchSubjectGrades()
    }

    private fun fetchSubjectGrades() {
        viewModelScope.launch {
            repository.getAllSubjectGrades().collect { subjectGrades ->
                _subjectGradesStateFlow.value = subjectGrades
                if (subjectGrades.isEmpty()) {
                    _averageGradeStateFlow.value = 0.0
                } else {
                    _averageGradeStateFlow.value = subjectGrades.map { it.grade }.average()
                }
            }
        }
    }


}

class SubjectGradeListViewModelFactory(val application: Application) :
    ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return SubjectGradeListViewModel(application) as T
    }
}