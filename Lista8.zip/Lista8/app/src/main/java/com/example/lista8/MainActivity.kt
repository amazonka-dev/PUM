package com.example.lista8

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.lista8.ui.theme.Lista8Theme
import androidx.compose.foundation.layout.Box as Box

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val navController = rememberNavController()

            Lista8Theme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        Navigation(navController)
                    }
                }
            }
        }
    }
}

sealed class Screens(val route: String) {
    data object SubjectGradeListScreen : Screens("subject_grade_list_screen")
    data object EditSubjectScreen : Screens("edit_subject_screen")
    data object NewSubjectScreen : Screens("new_subject_screen")

}

@Composable
fun Navigation(navController: NavHostController) {
    NavHost(
        navController = navController,
        startDestination = Screens.SubjectGradeListScreen.route
    ) {
        composable(route = Screens.SubjectGradeListScreen.route) {
            SubjectGradeListScreen(onAddNewSubjectGradeClicked = {
                navController.navigate(Screens.NewSubjectScreen.route)
            }, onEditSubjectGradeClicked = { id ->
                navController.navigate(Screens.EditSubjectScreen.route + "/$id")
            })
        }

        composable(route = Screens.EditSubjectScreen.route + "/{id}",
            arguments = listOf(
                navArgument("id") {
                    type = NavType.IntType
                }
            )) {
            val id = it.arguments?.getInt("id")!!
            EditSubjectGradeScreen(id, onComplete = {
                navController.popBackStack()
            })
        }

        composable(
            route = Screens.NewSubjectScreen.route,
        ) {
            NewSubjectGradeScreen(onComplete = {
                navController.popBackStack()
            })
        }

    }
}

@Composable
fun SubjectGradeListScreen(
    onAddNewSubjectGradeClicked: () -> Unit,
    onEditSubjectGradeClicked: (Int) -> Unit
) {
    val viewModel: SubjectGradeListViewModel = viewModel(
        LocalViewModelStoreOwner.current!!,
        "SubjectGradeListViewModel",
        SubjectGradeListViewModelFactory(LocalContext.current.applicationContext as Application)
    )
    val subjectGrades by viewModel.subjectGradesStateFlow.collectAsStateWithLifecycle()
    val averageGrade by viewModel.averageGradeStateFlow.collectAsStateWithLifecycle()

    Column {
        Text("Moje oceny", fontSize = 20.sp)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            items(subjectGrades.size) {
                val subjectGrade by remember {
                    mutableStateOf(subjectGrades[it])
                }
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp)
                        .clickable(onClick = {
                            onEditSubjectGradeClicked(subjectGrade.id)
                        })
                ) {
                    Text(subjectGrade.subject, fontSize = 20.sp)
                    Text("${subjectGrade.grade}", fontSize = 20.sp)

                }
            }
        }
        Text("Średnia ocen:", fontSize = 20.sp)
        Text("%.1f".format(averageGrade), fontSize = 20.sp)
        Button(onClick = onAddNewSubjectGradeClicked) {
            Text(text = "NOWY")
        }
    }
}

@Composable
fun EditSubjectGradeScreen(subjectGradeId: Int, onComplete: () -> Unit) {
    val viewModel: EditSubjectGradeViewModel = viewModel(
        LocalViewModelStoreOwner.current!!,
        "EditSubjectViewModel",
        EditSubjectGradeViewModelFactory(
            subjectGradeId,
            LocalContext.current.applicationContext as Application
        )
    )
    val subject by viewModel.subjectStateFlow.collectAsStateWithLifecycle()
    val gradeText by viewModel.gradeStateFlow.collectAsStateWithLifecycle()

    Column {
        Text("Edytuj", fontSize = 20.sp)

        TextField(value = subject, onValueChange = {
            viewModel.updateSubject(it)
        }, label = { Text("Nazwa przedmiotu") })
        TextField(value = gradeText, onValueChange = {
            viewModel.updateGrade(it)
        }, label = { Text("Ocena") })

        Button(onClick = {
            val grade = gradeText.toDoubleOrNull()
            if (grade != null) {
                viewModel.updateSubjectGrade(subject, grade)
                onComplete()
            }
        }) {
            Text(text = "ZAPISZ")
        }

        Button(onClick = {
            viewModel.deleteSubjectGrade()
            onComplete()
        }) {
            Text(text = "USUŃ")
        }
    }
}

@Composable
fun NewSubjectGradeScreen(onComplete: () -> Unit) {
    val viewModel: NewSubjectGradeViewModel = viewModel(
        LocalViewModelStoreOwner.current!!,
        "NewSubjectViewModel",
        NewSubjectGradeViewModelFactory(LocalContext.current.applicationContext as Application)
    )
    var subject by remember { mutableStateOf("") }
    var gradeText by remember { mutableStateOf("") }

    Column {
        Text("Dodaj nowy", fontSize = 20.sp)
        Text("Nazwa przedmiotu:", fontSize = 20.sp)

        TextField(value = subject, onValueChange = {
            subject = it
        })
        Text("Ocena:", fontSize = 20.sp)
        TextField(value = gradeText, onValueChange = {
            gradeText = it
        })
        Button(onClick = {
            val grade = gradeText.toDoubleOrNull()
            if (grade != null) {
                viewModel.addSubjectGrade(subject, grade)
                onComplete()
            }
        }) {
            Text(text = "ZAPISZ")
        }
    }
}