package com.example.lista8

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "subject_grades")
data class SubjectGrade (
    @PrimaryKey(autoGenerate = true) val id: Int,
    val subject: String,
    val grade: Double
)

@Dao
interface  SubjectGradeDao {
    @Query("SELECT * FROM subject_grades")
    fun getAllSubjectGrades(): Flow<List<SubjectGrade>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(subjectGrade: SubjectGrade)

    @Update
    suspend fun update(subjectGrade: SubjectGrade)

    @Query("DELETE FROM subject_grades WHERE id = :id")
    suspend fun delete(id: Int)

    @Query("SELECT * FROM subject_grades WHERE id = :id")
    suspend fun findSubjectGradeById(id: Int): SubjectGrade

}

@Database(entities = [SubjectGrade::class], version = 1, exportSchema = false)
abstract class SubjectGradeDatabase : RoomDatabase() {
    abstract fun SubjectGradeDao(): SubjectGradeDao

    companion object {
        @Volatile
        private var Instance: SubjectGradeDatabase? = null

        fun getDatabase(context: Context): SubjectGradeDatabase {
            return Instance ?: synchronized(this) {
                Room.databaseBuilder(context, SubjectGradeDatabase::class.java, "subject_grade_database")
                    .build()
                    .also { Instance = it }
            }
        }
    }
}

class SubjectGradeRepository(private val subjectGradeDao: SubjectGradeDao) {
    fun getAllSubjectGrades() = subjectGradeDao.getAllSubjectGrades()
    suspend fun add(subjectGrade: SubjectGrade) = subjectGradeDao.insert(subjectGrade)
    suspend fun update(subjectGrade: SubjectGrade) = subjectGradeDao.update(subjectGrade)
    suspend fun delete(subjectGradeId: Int) = subjectGradeDao.delete(subjectGradeId)
    suspend fun findSubjectGradeById(subjectGradeId: Int) = subjectGradeDao.findSubjectGradeById(subjectGradeId)
}