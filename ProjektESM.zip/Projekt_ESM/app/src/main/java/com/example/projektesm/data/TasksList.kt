package com.example.projektesm.data

class TasksList (val id: Int, val name: String)

const val PersonalTaskListId = 1
const val WorkTaskListId = 2
const val LearningTaskListId = 3

val tasksLists = listOf<TasksList>(
    TasksList(PersonalTaskListId, "Dom"), TasksList(WorkTaskListId, "Praca"), TasksList(
        LearningTaskListId, "Nauka")
)

fun getTasksListName(listId: Int): String {
    return tasksLists.find { it.id == listId }?.name ?: ""
}