package com.example.projektesm.data

import com.example.projektesm.ui.views.SortFieldPriority
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class TaskRepository(private val taskDao: TaskDao) {
    //fun getTasksOnList(taskListId: Int) = taskDao.getTasksOnList(taskListId)

    //fun getTasksOnListSortedByPriority(taskListId: Int, isAscending: Boolean) = taskDao.getTasksOnList(taskListId).map {
    //    if (isAscending) {
    //        it.sortedBy { sortList -> sortList.priority }
    //    } else {
    //        it.sortedByDescending { sortList -> sortList.priority }
     //   }
    //}

    //fun getTasksOnListSortedByContent(taskListId: Int, isAscending: Boolean) = taskDao.getTasksOnList(taskListId).map {
    //    if (isAscending) {
    //        it.sortedBy { sortList -> sortList.content }
     //   } else {
      //      it.sortedByDescending { sortList -> sortList.content }
      //  }

    fun getTasksOnList(

        taskListId: Int,

        contentFilter: String,

        hideCompleted: Boolean,

        priorityFilter: Int,

        sortByField: String,

        sortOrderDescending: Boolean

    ): Flow<List<Task>> {

        return taskDao.getTasksOnList(taskListId, contentFilter, hideCompleted, priorityFilter).map {

            if (sortByField == SortFieldPriority) {

                if (sortOrderDescending) {

                    it.sortedByDescending { it.priority }

                } else {

                    it.sortedBy { it.priority }

                }

            } else {

                if (sortOrderDescending) {
                    it.sortedBy { it.content }


                } else {
                    it.sortedByDescending { it.content }



                }

            }

        }

    }




    suspend fun add(task: Task) = taskDao.insert(task)
    suspend fun update(task: Task) = taskDao.update(task)
    suspend fun delete(id: Int) = taskDao.delete(id)
    suspend fun findTaskById(id: Int) = taskDao.findTaskById(id)
}