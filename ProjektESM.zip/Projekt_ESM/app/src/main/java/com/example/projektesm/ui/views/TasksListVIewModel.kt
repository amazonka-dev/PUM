package com.example.projektesm.ui.views

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.projektesm.data.Task
import com.example.projektesm.data.TaskRepository
import com.example.projektesm.data.TasksDatabase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

const val SortFieldContent = "content"

const val SortFieldPriority = "priority"



const val PriorityFilterNone = 0

const val PriorityFilterHigh = 1

const val PriorityFilterLow = -1
class TasksListViewModel(private val listId: Int, application: Application) : ViewModel() {
    private val repository: TaskRepository

    private val _tasksStateFlow = MutableStateFlow<List<Task>>(emptyList())
    val tasksStateFlow = _tasksStateFlow.asStateFlow()

    private val _contentFilterStateFlow = MutableStateFlow("")

    val contentFilterStateFlow = _contentFilterStateFlow.asStateFlow()



    private val _priorityFilterStateFlow = MutableStateFlow(0)

    val priorityFilterStateFlow = _priorityFilterStateFlow.asStateFlow()



    private val _hideCompletedStateFlow = MutableStateFlow(false)

    val hideCompletedStateFlow = _hideCompletedStateFlow.asStateFlow()



    private val _sortFieldStateFlow = MutableStateFlow(SortFieldPriority)

    val sortFieldStateFlow = _sortFieldStateFlow.asStateFlow()



    private val _sortOrderDescendingStateFlow = MutableStateFlow(true)

    val sortOrderDescendingStateFlow = _sortOrderDescendingStateFlow.asStateFlow()


    init {
        val db = TasksDatabase.getDatabase(application)
        val dao = db.taskDao()
        repository = TaskRepository(dao)

        fetchTasks()
    }

    //private fun fetchTasks() {
    //    viewModelScope.launch {
    //        repository.getTasksOnList(listId).collect {
     //           _tasksStateFlow.value = it
      //      }
            //repository.getTasksOnListSortedByContent(listId, true)
            //repository.getTasksOnListSortedByPriority(listId, true)
     //   }
    //}

    private fun fetchTasks() {

        viewModelScope.launch {

            repository.getTasksOnList(

                listId,

                _contentFilterStateFlow.value,

                _hideCompletedStateFlow.value,

                _priorityFilterStateFlow.value,

                _sortFieldStateFlow.value,

                _sortOrderDescendingStateFlow.value

            )

                .collect {

                    _tasksStateFlow.value = it

                }

        }

    }

    fun updateTaskCompleted(completed: Boolean, taskId: Int) {
        val task = _tasksStateFlow.value.find { it.id == taskId }
        if (task != null) {
            val updatedTask = Task(task.id, task.content, task.priority, completed, task.taskListId)
            viewModelScope.launch {
                repository.update(updatedTask)
                fetchTasks()
            }
        }
    }

    fun updateContentFilter(contentFilter: kotlin.String) {

        _contentFilterStateFlow.value = contentFilter

        fetchTasks()

    }

    fun cyclePriorityFilter() {

        val nextPriorityFilter = calculateNextPriorityFilter()

        updatePriorityFilter(nextPriorityFilter)

    }



    private fun calculateNextPriorityFilter(): Int {

        return when (_priorityFilterStateFlow.value) {

            PriorityFilterLow -> PriorityFilterNone

            PriorityFilterNone -> PriorityFilterHigh

            PriorityFilterHigh -> PriorityFilterLow

            else -> PriorityFilterNone

        }

    }



    private fun updatePriorityFilter(priorityFilter: Int) {

        _priorityFilterStateFlow.value = priorityFilter

        fetchTasks()

    }



    fun cycleSortField() {

        val nextSortField = if (_sortFieldStateFlow.value == SortFieldPriority) {

            SortFieldContent

        } else {

            SortFieldPriority

        }

        updateSortField(nextSortField)

    }



    private fun updateSortField(sortField: String) {

        _sortFieldStateFlow.value = sortField

        fetchTasks()

    }



    fun toggleSortOrder() {

        updateSortOrder(!_sortOrderDescendingStateFlow.value)

    }



    private fun updateSortOrder(descending: Boolean) {

        _sortOrderDescendingStateFlow.value = descending

        fetchTasks()

    }



    fun toggleHideCompleted() {

        updateHideCompleted(!_hideCompletedStateFlow.value)

    }



    private fun updateHideCompleted(hide: Boolean) {

        _hideCompletedStateFlow.value = hide

        fetchTasks()

    }


}

class TasksListViewModelFactory(private val listId: Int, private val application: Application) :
    ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return TasksListViewModel(listId, application) as T
    }
}

