package com.example.projektesm.ui.views

import android.app.Application
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.projektesm.R
import com.example.projektesm.data.getTasksListName
import com.example.projektesm.ui.TextPriority

@Composable
fun TasksListScreen(
    listId: Int,
    onEditTaskRequested: (Int) -> Unit,
    onAddTaskRequested: () -> Unit
) {
    val viewModel: TasksListViewModel = viewModel(
        LocalViewModelStoreOwner.current!!,
        "TasksListViewModel",
        TasksListViewModelFactory(listId, LocalContext.current.applicationContext as Application)
    )

    val tasks by viewModel.tasksStateFlow.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize()) {
        FilterAndSortToolbar(viewModel)
        Text(
            getTasksListName(listId), textAlign = TextAlign.Center, modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 20.dp)
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 40.dp)
        ) {
            items(tasks.size) {
                val task = tasks[it]
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(all = 10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .padding(horizontal = 20.dp, vertical = 10.dp)
                            .fillMaxWidth()
                    ) {
                        Checkbox(task.completed, onCheckedChange = {
                            viewModel.updateTaskCompleted(!task.completed, task.id)
                        })
                        Text(
                            tasks[it].content,
//                            "${tasks[it].content}=${tasks[it].completed}",
                            style = TextStyle.Default.copy(textDecoration = if (task.completed) TextDecoration.LineThrough else TextDecoration.None),
                            modifier = Modifier
                                .weight(0.7f)
                                .clickable {
                                    viewModel.updateTaskCompleted(!task.completed, task.id)
                                }
                        )
                        TextPriority(task.priority)
                        Button({
                            onEditTaskRequested(task.id)
                        }, modifier = Modifier.padding(start = 20.dp)) {
                            Text(text = "Edytuj")
                        }
                    }
                }
            }
        }

        Button(
            onClick = {
                onAddTaskRequested()
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp)
        ) {
            Text(text = "Dodaj zadanie")
        }
    }
}
@Composable

fun FilterAndSortToolbar(viewModel: TasksListViewModel) {

    val contentFilter by viewModel.contentFilterStateFlow.collectAsStateWithLifecycle()

    val priorityFilter by viewModel.priorityFilterStateFlow.collectAsStateWithLifecycle()

    val hideCompleted by viewModel.hideCompletedStateFlow.collectAsStateWithLifecycle()

    val sortField by viewModel.sortFieldStateFlow.collectAsStateWithLifecycle()

    val sortOrderDescending by viewModel.sortOrderDescendingStateFlow.collectAsStateWithLifecycle()



    val priorityIconTint = when (priorityFilter) {

        PriorityFilterLow -> Color.Green

        PriorityFilterHigh -> Color.Red

        else -> Color.Blue

    }

    val priorityIcon = when (priorityFilter) {

        PriorityFilterLow -> R.drawable.baseline_arrow_downward_24

        PriorityFilterHigh -> R.drawable.baseline_priority_high_24

        else -> R.drawable.baseline_filter_list_off_24

    }



    val sortFieldIcon = if (sortField == SortFieldPriority) {

        R.drawable.baseline_priority_high_24

    } else {

        R.drawable.baseline_text_format_24

    }



    val sortOrderIcon = if (sortOrderDescending) {

        R.drawable.baseline_arrow_downward_24

    } else {

        R.drawable.baseline_arrow_upward_24

    }



    val hideCompletedIcon = if (hideCompleted) {

        R.drawable.baseline_remove_done_24

    } else {

        R.drawable.baseline_done_outline_24

    }



    Row(

        horizontalArrangement = Arrangement.SpaceBetween,

        verticalAlignment = Alignment.CenterVertically,

        modifier = Modifier

            .fillMaxWidth()

            .padding(bottom = 20.dp)

            .padding(horizontal = 10.dp)

    ) {

        TextField(

            contentFilter,

            onValueChange = {

                viewModel.updateContentFilter(it)

            }, modifier = Modifier

                .weight(1f)

        )

        Image(

            painter = painterResource(id = priorityIcon),

            colorFilter = ColorFilter.tint(priorityIconTint),

            contentDescription = "priority filter",

            modifier = Modifier

                .clickable {

                    viewModel.cyclePriorityFilter()

                }

                .padding(horizontal = 10.dp)

        )

        Image(

            painter = painterResource(id = hideCompletedIcon),

            contentDescription = "completed filter",

            modifier = Modifier

                .clickable {

                    viewModel.toggleHideCompleted()

                }

                .padding(horizontal = 10.dp)

        )

        Image(

            painter = painterResource(id = sortFieldIcon),

            contentDescription = "sort field",

            modifier = Modifier

                .clickable {

                    viewModel.cycleSortField()

                }

                .padding(start = 20.dp)

        )

        Image(

            painter = painterResource(id = sortOrderIcon),

            contentDescription = "sort order",

            modifier = Modifier

                .clickable {

                    viewModel.toggleSortOrder()

                }

        )

    }

}

