package com.example.projektesm.ui.views

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.projektesm.data.Task
import com.example.projektesm.data.TaskRepository
import com.example.projektesm.data.TasksDatabase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class NewTaskViewModel(private val listId: Int, application: Application) : ViewModel() {
    private val repository: TaskRepository

    private val _contentStateFlow = MutableStateFlow("")
    val contentStateFlow = _contentStateFlow.asStateFlow()

    private val _priorityStateFlow = MutableStateFlow(0)
    val priorityStateFlow = _priorityStateFlow.asStateFlow()

    init {
        val db = TasksDatabase.getDatabase(application)
        val dao = db.taskDao()
        repository = TaskRepository(dao)
    }

    fun addTask() {
        viewModelScope.launch {
            repository.add(
                Task(
                    0,
                    _contentStateFlow.value,
                    _priorityStateFlow.value,
                    false,
                    listId
                )
            )
        }
    }

    fun updateContent(content: String) {
        _contentStateFlow.update { content }
    }

    fun updatePriority(priority: Int) {
        _priorityStateFlow.update { priority }
    }
}

class NewTaskViewModelFactory(private val listId: Int, private val application: Application) :
    ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return NewTaskViewModel(listId, application) as T
    }
}
