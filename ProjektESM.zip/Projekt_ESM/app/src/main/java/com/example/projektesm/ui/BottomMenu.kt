package com.example.projektesm.ui

import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.vectorResource
import androidx.navigation.NavHostController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.example.projektesm.R
import com.example.projektesm.data.LearningTaskListId
import com.example.projektesm.data.PersonalTaskListId
import com.example.projektesm.data.WorkTaskListId
import com.example.projektesm.data.getTasksListName

sealed class BottomMenu(
    val route: String,
    val title: String,
    val drawableId: Int
) {
    data object PersonalListTasks :
        BottomMenu(
            Screens.PersonalListTasksScreen.route,
            getTasksListName(PersonalTaskListId),
            R.drawable.baseline_home_24
        )

    data object WorkListTasks : BottomMenu(
        Screens.WorkListTasksScreen.route,
        getTasksListName(WorkTaskListId),
        R.drawable.baseline_work_24
    )

    data object LearningListTasks :
        BottomMenu(
            Screens.LearningListTasksScreen.route,
            getTasksListName(LearningTaskListId),
            R.drawable.baseline_school_24
        )
}

@Composable
fun BottomMenu(navController: NavHostController) {
    val screens = listOf(
        BottomMenu.PersonalListTasks, BottomMenu.WorkListTasks, BottomMenu.LearningListTasks
    )

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    NavigationBar {
        screens.forEach { screen ->
            NavigationBarItem(
                label = { Text(text = screen.title) },
                icon = {
                    Icon(
                        imageVector = ImageVector.vectorResource(screen.drawableId),
                        contentDescription = "icon"
                    )
                },
                selected = currentDestination?.route == screen.route,
                onClick = { navController.navigate(screen.route) }
            )
        }
    }
}