package com.example.projektesm.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {
   // @Query("SELECT * FROM tasks_table WHERE taskListId = :taskListId")
    //fun getTasksOnList(taskListId: Int): Flow<List<Task>>

    @Query(

        "SELECT * FROM tasks_table " +

                "WHERE taskListId = :taskListId AND (" +

                "(:contentFilter = '' OR content LIKE '%' || :contentFilter || '%') AND " +

                "(:priorityFilter = 0 OR (priority < 0 AND :priorityFilter = -1) OR (priority > 0 AND :priorityFilter = 1)) AND " +

                "(:hideCompleted = 0 OR completed = 0) " +

                ")"

    )

    fun getTasksOnList(

        taskListId: Int,

        contentFilter: String,

        hideCompleted: Boolean,

        priorityFilter: Int

    ): Flow<List<Task>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(task: Task)

    @Update
    suspend fun update(task: Task)

    @Query("DELETE FROM tasks_table WHERE id = :id")
    suspend fun delete(id: Int)

    @Query("SELECT * FROM tasks_table WHERE id = :id")
    suspend fun findTaskById(id: Int): Task

}