package com.example.projektesm.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tasks_table")
data class Task (
    @PrimaryKey(autoGenerate = true)
    val id: Int,
    var content: String,
    var priority: Int,
    var completed : Boolean,
    var taskListId : Int
)