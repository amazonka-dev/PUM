package com.example.projektesm

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.projektesm.data.PersonalTaskListId
import com.example.projektesm.data.tasksLists
import com.example.projektesm.ui.BottomMenu
import com.example.projektesm.ui.views.EditTaskScreen
import com.example.projektesm.ui.views.NewTaskScreen
import com.example.projektesm.ui.Screens
import com.example.projektesm.ui.views.TasksListScreen
import com.example.projektesm.ui.getTaskListScreenRoute
import com.example.projektesm.ui.theme.ProjektESMTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val navController = rememberNavController()
            ProjektESMTheme {
                Scaffold(modifier = Modifier.fillMaxSize(), bottomBar = {
                    BottomMenu(navController = navController)
                }) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        Navigation(navController)
                    }
                }
            }
        }
    }
}

@Composable
fun Navigation(navController: NavHostController) {
    Column() {
        NavHost(
            navController = navController,
            startDestination = getTaskListScreenRoute(PersonalTaskListId)
        ) {
            for (tasksList in tasksLists) {
                composable(route = getTaskListScreenRoute(tasksList.id)) {
                    TasksListScreen(tasksList.id, { taskId: Int ->
                        navController.navigate(Screens.EditTaskScreen.route + "/${tasksList.id}/${taskId}")
                    }, {
                        navController.navigate(Screens.NewTaskScreen.route + "/${tasksList.id}")
                    })
                }
            }

            composable(
                route = Screens.EditTaskScreen.route + "/{listId}/{taskId}",
                arguments = listOf(navArgument("listId") {
                    type = NavType.IntType
                }, navArgument("taskId") {
                    type = NavType.IntType
                })
            ) {
                val listId = it.arguments?.getInt("listId")!!
                val taskId = it.arguments?.getInt("taskId")!!
                EditTaskScreen(listId, taskId) { navController.popBackStack() }
            }

            composable(
                route = Screens.NewTaskScreen.route + "/{listId}",
                arguments = listOf(navArgument("listId") {
                    type = NavType.IntType
                })
            ) {
                val listId = it.arguments?.getInt("listId")!!
                NewTaskScreen(listId) { navController.popBackStack() }
            }
        }
    }
}

