package com.example.projektesm.ui.views

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.projektesm.data.Task
import com.example.projektesm.data.TaskRepository
import com.example.projektesm.data.TasksDatabase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class EditTaskViewModel(
    private val taskId: Int,
    private val listId: Int,
    application: Application
) : ViewModel() {
    private val repository: TaskRepository

    private val _contentStateFlow = MutableStateFlow("")
    val contentStateFlow = _contentStateFlow.asStateFlow()

    private val _priorityStateFlow = MutableStateFlow(0)
    val priorityStateFlow = _priorityStateFlow.asStateFlow()

    private val _completedStateFlow = MutableStateFlow(false)
    val completedStateFlow = _completedStateFlow.asStateFlow()

    init {
        val db = TasksDatabase.getDatabase(application)
        val dao = db.taskDao()
        repository = TaskRepository(dao)

        fetchTask()
    }

    private fun fetchTask() {
        viewModelScope.launch {
            val task = repository.findTaskById(taskId)
            _contentStateFlow.update { task.content }
            _completedStateFlow.update { task.completed }
            _priorityStateFlow.update { task.priority }
        }
    }

    fun deleteTask(taskId: Int) {
        viewModelScope.launch {
            repository.delete(taskId)
        }
    }

    fun updateTask() {
        viewModelScope.launch {
            repository.update(
                Task(
                    taskId,
                    _contentStateFlow.value,
                    _priorityStateFlow.value,
                    _completedStateFlow.value,
                    listId
                )
            )
        }
    }

    fun updateContent(content: String) {
        _contentStateFlow.update { content }
    }

    fun updateCompleted(completed: Boolean) {
        _completedStateFlow.update { completed }
    }

    fun updatePriority(priority: Int) {
        _priorityStateFlow.update { priority }
    }
}

class EditTaskViewModelFactory(private val taskId: Int, private val listId: Int, private val application: Application) :
    ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return EditTaskViewModel(taskId, listId, application) as T
    }
}
