package com.example.projektesm.ui

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp

@Composable
fun TextPriority(priority: Int, modifier: Modifier = Modifier) {
    var color = Color.Black

    if (priority < 0) {
        color = Color.Green
    } else if (priority > 0) {
        color = Color.Red
    }

    var priorityText = ""
    if (priority == -3) {
        priorityText = "⬇⬇⬇"
    } else if (priority == -2) {
        priorityText = "⬇⬇"
    } else if (priority == -1) {
        priorityText = "⬇"
    } else if (priority == 1) {
        priorityText = "!"
    }
    if (priority == 2) {
        priorityText = "!!"
    }
    if (priority == 3) {
        priorityText = "!!!"
    }
    return Text(
        priorityText,
        textAlign = TextAlign.Center,
        color = color,
        fontSize = 20.sp,
        modifier = modifier
    )
}