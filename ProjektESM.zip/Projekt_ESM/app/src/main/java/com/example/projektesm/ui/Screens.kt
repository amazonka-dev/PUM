package com.example.projektesm.ui

import com.example.projektesm.data.LearningTaskListId
import com.example.projektesm.data.PersonalTaskListId
import com.example.projektesm.data.WorkTaskListId

sealed class Screens(val route: String) {
    data object PersonalListTasksScreen : Screens(getTaskListScreenRoute(PersonalTaskListId))
    data object WorkListTasksScreen : Screens(getTaskListScreenRoute(WorkTaskListId))
    data object LearningListTasksScreen : Screens(getTaskListScreenRoute(LearningTaskListId))
    data object EditTaskScreen : Screens("edit_task")
    data object NewTaskScreen : Screens("new_task")
}

fun getTaskListScreenRoute(listId: Int): String {
    return "list_tasks_$listId"
}