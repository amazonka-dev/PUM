package com.example.projektesm.ui.views

import android.app.Application
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.projektesm.data.getTasksListName
import com.example.projektesm.ui.TextPriority

@Composable
fun NewTaskScreen(listId: Int, onComplete: () -> Unit) {
    val viewModel: NewTaskViewModel = viewModel(
        LocalViewModelStoreOwner.current!!,
        "NewTaskViewModel",
        NewTaskViewModelFactory(listId, LocalContext.current.applicationContext as Application)
    )
    val content by viewModel.contentStateFlow.collectAsStateWithLifecycle()
    val priority by viewModel.priorityStateFlow.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier.fillMaxWidth(),
    ) {

        Text(
            "Dodaj zadanie", textAlign = TextAlign.Center, modifier = Modifier
                .padding(vertical = 20.dp)
                .padding(bottom = 20.dp)
                .fillMaxWidth()
        )

        TextField(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp)
                .padding(bottom = 20.dp)
                .align(Alignment.CenterHorizontally),
            value = content,
            onValueChange = { viewModel.updateContent(it) },
            label = { Text("Zadanie") }
        )

        Row(
            verticalAlignment = Alignment.CenterVertically, modifier = Modifier
                .padding(bottom = 20.dp)
                .padding(horizontal = 10.dp)
        ) {
            Text("lista:")
            Text(getTasksListName(listId), modifier = Modifier.padding(start = 20.dp))
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier
                .padding(bottom = 20.dp)
                .padding(horizontal = 10.dp)
        ) {
            Text("priorytet:")
            Button({
                if (priority > -3) {
                    viewModel.updatePriority(priority - 1)
                }
            }) {
                Text("zmniejsz")
            }
            TextPriority(
                priority, modifier = Modifier
                    .width(40.dp)
            )
            Button({
                if (priority < 3) {
                    viewModel.updatePriority(priority + 1)
                }
            }) {
                Text("zwiększ")
            }
        }

        Button(
            onClick = {
                if (content.isNotEmpty()) {
                    viewModel.addTask()
                    onComplete()
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp)
        ) {
            Text(text = "ZAPISZ")
        }
    }
}