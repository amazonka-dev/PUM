package com.example.lista2_login_service;

import java.util.ArrayList;
import java.util.List;

public class UsersDatabase {
    private static List<User> users = new ArrayList<>();
    public static void initDatabase() {
        users.clear();
        addUser("user1", "pass");
        addUser("user2", "pass");
        addUser("user3", "pass");
        addUser("user4", "pass");
        addUser("user5", "pass");

    }
    public static boolean canLogin(String login, String pasword){
        for(User user:users){
            if(user.getLogin().equals(login) && user.getPassword().equals(pasword)) {
                return true;
            }
        }
        return false;
    }

    public static boolean userExists(String login){
        for(User user:users){
            if(user.getLogin().equals(login)) {
                return true;
            }
        }
        return false;
    }


    public static void addUser(String login, String password) {
        users.add(new User(login, password));

    }

}
